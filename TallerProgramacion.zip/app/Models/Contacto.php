<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Contacto extends Model
{
    //
    use HasFactory;
    protected $table = 'table_contacto';
    protected $fillable = [
        'name',
        'email',
        'phone',
        'curso',
    ];

    

}
